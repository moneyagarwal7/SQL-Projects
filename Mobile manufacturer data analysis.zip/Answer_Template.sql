--SQL Advance Case Study

SELECT * FROM DIM_LOCATION
SELECT * FROM DIM_CUSTOMER
SELECT * FROM DIM_DATE
SELECT * FROM DIM_MANUFACTURER
SELECT * FROM DIM_MODEL
SELECT * FROM FACT_TRANSACTIONS
--Q1--BEGIN 
--All the states in which we have customers who have bought cellphones from 2005 till today.
SELECT distinct State FROM FACT_TRANSACTIONS T1
INNER JOIN DIM_LOCATION T2 ON T1.IDLocation= T2.IDLocation
INNER JOIN DIM_MODEL T3 ON T1.IDModel= T3.IDModel
join DIM_DATE T4 on T1.DATE =T4.DATE
WHERE YEAR > = 2005 
--Q1--END

--Q2--BEGIN
--State in the US is buying more 'Samsung' cell phones?

Select top 1 State from DIM_LOCATION
Inner join FACT_TRANSACTIONS ON DIM_LOCATION.IDLocation=FACT_TRANSACTIONS.IDLocation
Inner join DIM_MODEL on FACT_TRANSACTIONS.IDModel= DIM_Model.IDModel
Inner join DIM_MANUFACTURER ON DIM_MANUFACTURER.IDManufacturer = DIM_MODEL.IDManufacturer
Where Manufacturer_Name = 'Samsung' and Country = 'US'
Group by State
order by sum(Quantity) desc
--Q2--END

--Q3--BEGIN      
--The number of transactions for each model per zip code per state.
select Model_Name,ZipCode,State, count(IDCustomer) AS no_of_transactions from DIM_LOCATION
Inner join FACT_TRANSACTIONS on DIM_LOCATION.IDLocation =FACT_TRANSACTIONS.IDLocation
Inner join DIM_MODEL on FACT_TRANSACTIONS.IDModel = DIM_MODEL.IDModel
Group by Model_Name,ZipCode,State
--Q3--END

--Q4--BEGIN
--Show the cheapest cellphone
Select top 1 IDModel, Model_Name,Unit_price from DIM_MODEL
order by Unit_price asc
--Q4--END

--Q5--BEGIN
--The average price for each model in the top5 manufacturers in terms of sales quantity and order by average price.
SELECT top 5 Manufacturer_Name, Model_Name, sum(Quantity) as Total_Sale_Quantity, AVG(totalprice)
as AVG_Price FROM FACT_TRANSACTIONS AS T 
INNER JOIN DIM_MODEL AS M ON T.IDModel=M.IDModel 
INNER JOIN DIM_MANUFACTURER AS M1 ON M.IDManufacturer=M1.IDManufacturer
GROUP BY Manufacturer_Name, Model_Name
order by Total_Sale_Quantity desc , AVG_Price asc
--Q5--END

--Q6--BEGIN
--The names of the customers and the average amount spent in 2009, where the average is higher than 500
SELECT Customer_Name, AVG(TotalPrice) AVG_SPENT FROM DIM_CUSTOMER
INNER JOIN FACT_TRANSACTIONS ON DIM_CUSTOMER.IDCustomer = FACT_TRANSACTIONS.IDCustomer
WHERE YEAR(Date) = 2009 
GROUP BY Customer_Name
HAVING AVG(TotalPrice)>500
--Q6--END
	
--Q7--BEGIN  
--List if there is any model that was in the top 5 in terms of quantity, simultaneously in 2008, 2009 and 2010	
select Model_Name
from (select top 5 Model_Name, sum(Quantity) as quantity_, YEAR
from FACT_TRANSACTIONS f
join DIM_MODEL mo
on f.IDModel= mo.IDModel
join DIM_DATE d
on f.Date = d.DATE	
WHERE year =  2008 
group by Model_Name, YEAR
order by sum(Quantity) desc ) t1
INTERSECT
select Model_Name
from (select top 5 Model_Name, sum(Quantity) as quantity_, YEAR
from FACT_TRANSACTIONS f
join DIM_MODEL mo
on f.IDModel = mo.IDModel
join DIM_DATE d
on f.Date = d.DATE	
WHERE year =  2009 
group by Model_Name, YEAR
order by sum(Quantity) desc ) t1
INTERSECT
select Model_Name
from (select top 5 Model_Name, sum(Quantity) as quantity_, YEAR
from FACT_TRANSACTIONS f
join DIM_MODEL mo
on f.IDModel = mo.IDModel
join DIM_DATE d
on f.Date = d.DATE	
WHERE year =  2010 
group by Model_Name, YEAR
order by sum(Quantity) desc ) t1
--Q7--END	

--Q8--BEGIN
--The manufacturer with the 2nd top sales in the year of 2009 and the manufacturer with the 2nd top sales in the year of 2010.
select * from (
select top 1 Manufacturer_Name, sum(TotalPrice) as sales
from (select top 2 Manufacturer_Name, sum(TotalPrice) as totalprice from 
FACT_TRANSACTIONS f
right join DIM_MODEL mo
on f.IDModel = mo.IDModel
right join DIM_MANUFACTURER ma
on mo.IDManufacturer = ma.IDManufacturer
right join DIM_DATE d
on f.Date = d.DATE
where year = 2009
group by Manufacturer_Name
order by sum(TotalPrice) desc) as subquery
group by Manufacturer_Name
order by sum(TotalPrice) asc) t3
Union
select * from (
select top 1 Manufacturer_Name, sum(TotalPrice) as sales
from (select top 2 Manufacturer_Name, sum(TotalPrice) as totalprice from 
FACT_TRANSACTIONS f
right join DIM_MODEL mo
on f.IDModel = mo.IDModel
right join DIM_MANUFACTURER ma
on mo.IDManufacturer = ma.IDManufacturer
right join DIM_DATE d
on f.Date = d.DATE
where year = 2010
group by Manufacturer_Name
order by sum(TotalPrice) desc) as subquery
group by Manufacturer_Name
order by sum(TotalPrice) asc) t3
--Q8--END

--Q9--BEGIN
--The manufacturers that sold cellphone in 2010 but didn�t in 2009.	
SELECT Manufacturer_Name FROM DIM_MANUFACTURER T1
INNER JOIN DIM_MODEL T2 ON T1.IDManufacturer= T2.IDManufacturer
INNER JOIN FACT_TRANSACTIONS T3 ON T2.IDModel= T3.IDModel
WHERE YEAR(DATE) = 2010 
EXCEPT 
SELECT Manufacturer_Name FROM DIM_MANUFACTURER T1
INNER JOIN DIM_MODEL T2 ON T1.IDManufacturer= T2.IDManufacturer
INNER JOIN FACT_TRANSACTIONS T3 ON T2.IDModel= T3.IDModel
WHERE YEAR(DATE) = 2009
--Q9--END

--Q10--BEGIN
--Top 100 customers and their average spend, average quantity by each year.Also find the percentage of change in their spend.
SELECT TOP 100 year(Date) year, 
    Customer_Name, 
    AVG(TotalPrice) AS Avg_total_price, 
    AVG(Quantity) AS Avg_quantity,
    100 * (AVG(TotalPrice) - LAG(AVG(TotalPrice)) 
	OVER (PARTITION BY Customer_Name ORDER BY year(date))) / LAG(AVG(TotalPrice)) 
	OVER (PARTITION BY Customer_Name ORDER BY year(date)) AS Percent_Change
FROM DIM_CUSTOMER c
JOIN FACT_TRANSACTIONS t ON c.IDCustomer = t.IDCustomer
GROUP BY Customer_Name, year(Date)
ORDER BY Avg_total_price DESC	
--Q10--END











